import pandas as pd
import numpy as np
import random
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import train_test_split
from textblob import TextBlob
import joblib

# File paths
MENU_FILE = "menu.xlsx"
ORDERS_FILE = "orders.xlsx"
MODEL_FILE = "delivery_model.pkl"

class MLDeliveryBot:
    def __init__(self, root):
        self.root = root
        self.root.title("AI-Powered Food Delivery Bot")
        self.root.geometry("1000x800")
        
        # Initialize ML components
        self.delivery_time_model = None
        self.recommendation_model = None
        self.vectorizer = TfidfVectorizer(stop_words='english')
        
        self.initialize_files()
        self.prepare_ml_models()
        self.create_widgets()
        
    def initialize_files(self):
        # Add category field to menu
        try:
            menu_df = pd.read_excel(MENU_FILE)
            if 'Category' not in menu_df.columns:
                menu_df['Category'] = ['Italian', 'Fast Food', 'Italian', 'Healthy', 'Snack']
                menu_df.to_excel(MENU_FILE, index=False)
        except FileNotFoundError:
            menu_data = {
                "ItemID": [101, 102, 103, 104, 105],
                "ItemName": ["Pizza", "Burger", "Pasta", "Salad", "Fries"],
                "Category": ["Italian", "Fast Food", "Italian", "Healthy", "Snack"],
                "Price": [12.99, 8.99, 10.99, 7.99, 4.99],
                "PreparationTime": [20, 15, 18, 10, 5]
            }
            pd.DataFrame(menu_data).to_excel(MENU_FILE, index=False)

        try:
            orders_df = pd.read_excel(ORDERS_FILE)
            if 'DeliveryTime' not in orders_df.columns:
                orders_df['DeliveryTime'] = [35, 25]  # Dummy delivery times
                orders_df.to_excel(ORDERS_FILE, index=False)
        except FileNotFoundError:
            orders_data = {
                "OrderID": [1001, 1002],
                "CustomerName": ["John Doe", "Jane Smith"],
                "ItemsOrdered": ["101,105", "102,104"],
                "TotalAmount": [22.97, 16.98],
                "Status": ["Delivered", "In Transit"],
                "Timestamp": ["2023-07-20 14:30", "2023-07-21 10:15"],
                "DeliveryTime": [35, 25]
            }
            pd.DataFrame(orders_data).to_excel(ORDERS_FILE, index=False)

    def prepare_ml_models(self):
        # Delivery Time Prediction Model
        try:
            self.delivery_time_model = joblib.load(MODEL_FILE)
        except:
            self.train_delivery_time_model()
            
        # Prepare Recommendation System
        self.prepare_recommendation_system()
        
    def train_delivery_time_model(self):
        orders_df = pd.read_excel(ORDERS_FILE)
        menu_df = pd.read_excel(MENU_FILE)
        
        # Feature Engineering
        orders_df['ItemCount'] = orders_df['ItemsOrdered'].apply(lambda x: len(x.split(',')))
        orders_df['TotalPrepTime'] = orders_df['ItemsOrdered'].apply(
            lambda x: sum(menu_df[menu_df['ItemID'].astype(str).isin(x.split(','))]['PreparationTime']))
        
        X = orders_df[['ItemCount', 'TotalPrepTime']]
        y = orders_df['DeliveryTime']
        
        self.delivery_time_model = RandomForestRegressor()
        self.delivery_time_model.fit(X, y)
        joblib.dump(self.delivery_time_model, MODEL_FILE)
        
    def prepare_recommendation_system(self):
        menu_df = pd.read_excel(MENU_FILE)
        orders_df = pd.read_excel(ORDERS_FILE)
        
        # Create item similarity matrix
        item_descriptions = menu_df['ItemName'] + " " + menu_df['Category']
        self.tfidf_matrix = self.vectorizer.fit_transform(item_descriptions)
        self.cosine_sim = cosine_similarity(self.tfidf_matrix, self.tfidf_matrix)

    def create_widgets(self):
        # Main Frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(pady=20, padx=20, fill=tk.BOTH, expand=True)

        # Buttons with ML features
        btn_style = ttk.Style()
        btn_style.configure('TButton', font=('Arial', 12))

        ttk.Button(main_frame, text="Place Order (AI)", command=self.enhanced_place_order_window).pack(pady=5, fill=tk.X)
        ttk.Button(main_frame, text="Check Order Status", command=self.check_status).pack(pady=5, fill=tk.X)
        ttk.Button(main_frame, text="Cancel Order", command=self.cancel_order).pack(pady=5, fill=tk.X)
        ttk.Button(main_frame, text="View Menu", command=self.display_menu).pack(pady=5, fill=tk.X)
        ttk.Button(main_frame, text="Exit", command=self.root.destroy).pack(pady=5, fill=tk.X)

    def check_status(self):
        order_id = simpledialog.askinteger("Order Status", "Enter your Order ID:")
        if order_id is None:
            return

        orders_df = pd.read_excel(ORDERS_FILE)
        try:
            order = orders_df[orders_df["OrderID"] == order_id].iloc[0]
            status_window = tk.Toplevel(self.root)
            status_window.title(f"Order Status - {order_id}")

            # Base order information
            info = f"""Order ID: {order_id}
Customer Name: {order['CustomerName']}
Items Ordered: {order['ItemsOrdered']}
Total Amount: ${order['TotalAmount']:.2f}
Status: {order['Status']}
Order Time: {order['Timestamp']}"""

            # Add ML prediction if order is pending
            if order["Status"] in ["Received", "Preparing", "In Transit"]:
                try:
                    items = list(map(int, order["ItemsOrdered"].split(',')))
                    predicted_time = self.predict_delivery_time(items)
                    info += f"\n\nPredicted Delivery Time: {predicted_time:.1f} minutes"
                except Exception as e:
                    info += "\n\nDelivery time prediction unavailable"

            # Create display labels
            ttk.Label(status_window, text=info, justify=tk.LEFT).pack(pady=20, padx=20)

        except IndexError:
            messagebox.showerror("Error", "Order not found!")
        except Exception as e:
            messagebox.showerror("Error", f"Error retrieving order: {str(e)}")

    def cancel_order(self):
        order_id = simpledialog.askinteger("Cancel Order", "Enter your Order ID:")
        if order_id is None:
            return

        try:
            orders_df = pd.read_excel(ORDERS_FILE)
            idx = orders_df.index[orders_df["OrderID"] == order_id].tolist()[0]
            
            if orders_df.at[idx, "Status"] == "Cancelled":
                messagebox.showinfo("Information", "Order is already cancelled!")
            else:
                orders_df.at[idx, "Status"] = "Cancelled"
                orders_df.to_excel(ORDERS_FILE, index=False)
                messagebox.showinfo("Success", "Order cancelled successfully!")
                
        except IndexError:
            messagebox.showerror("Error", "Order ID not found!")
        except Exception as e:
            messagebox.showerror("Error", f"Error cancelling order: {str(e)}")

    def display_menu(self):
        try:
            menu_df = pd.read_excel(MENU_FILE)
            menu_window = tk.Toplevel(self.root)
            menu_window.title("Current Menu")
            menu_window.geometry("600x400")

            # Create Treeview
            tree = ttk.Treeview(menu_window, columns=("ItemID", "ItemName", "Category", "Price"), show="headings")
            
            # Configure columns
            tree.column("ItemID", width=80, anchor=tk.CENTER)
            tree.column("ItemName", width=150, anchor=tk.W)
            tree.column("Category", width=120, anchor=tk.W)
            tree.column("Price", width=100, anchor=tk.E)
            
            # Configure headings
            tree.heading("ItemID", text="ID")
            tree.heading("ItemName", text="Item Name")
            tree.heading("Category", text="Category")
            tree.heading("Price", text="Price ($)")

            # Add scrollbar
            scrollbar = ttk.Scrollbar(menu_window, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)

            # Insert data
            for _, row in menu_df.iterrows():
                tree.insert("", "end", values=(
                    row["ItemID"],
                    row["ItemName"],
                    row["Category"],
                    f"{row['Price']:.2f}"
                ))

            # Add ML recommendation button
            ttk.Button(menu_window, text="Get Recommendations",
                      command=lambda: self.show_recommendations_popup()).pack(pady=10)

            tree.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        except FileNotFoundError:
            messagebox.showerror("Error", "Menu file not found!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load menu: {str(e)}")

    def show_recommendations_popup(self):
        item_id = simpledialog.askinteger("Recommendations", "Enter Item ID for recommendations:")
        if item_id:
            recommendations = self.get_recommendations(item_id)
            if recommendations:
                message = "Recommended items:\n- " + "\n- ".join(recommendations)
                messagebox.showinfo("Recommendations", message)
            else:
                messagebox.showinfo("Recommendations", "No recommendations available for this item")
        
    def get_recommendations(self, item_id, top_n=3):
        menu_df = pd.read_excel(MENU_FILE)
        idx = menu_df.index[menu_df['ItemID'] == item_id].tolist()[0]
        sim_scores = list(enumerate(self.cosine_sim[idx]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        sim_scores = sim_scores[1:top_n+1]
        item_indices = [i[0] for i in sim_scores]
        return menu_df['ItemName'].iloc[item_indices].tolist()
        
    def analyze_sentiment(self, text):
        analysis = TextBlob(text)
        return analysis.sentiment.polarity
        
    def predict_delivery_time(self, items):
        menu_df = pd.read_excel(MENU_FILE)
        item_count = len(items)
        total_prep_time = sum(menu_df[menu_df['ItemID'].isin(items)]['PreparationTime'])
        return self.delivery_time_model.predict([[item_count, total_prep_time]])[0]
        
    # GUI Components (similar structure as before with ML enhancements)
    def enhanced_place_order_window(self):
    # Initialize the order window
        if self.order_window and self.order_window.winfo_exists():
            self.order_window.lift()
        return
    
        self.order_window = tk.Toplevel(self.root)
        self.order_window.title("Place New Order - AI Enhanced")
        self.order_window.protocol("WM_DELETE_WINDOW", self.close_order_window)
    
    # Add your existing order window components here
        ttk.Label(self.order_window, text="Customer Name:").grid(row=0, column=0, padx=10, pady=5)
        self.name_entry = ttk.Entry(self.order_window)
        self.name_entry.grid(row=0, column=1, padx=10, pady=5)
    
    # Rest of your order window UI components
    # ... (your existing treeview, buttons, etc) ...
    
    # Add close handler
        self.order_window.bind('<Destroy>', lambda e: self.on_order_window_close())
def close_order_window(self):
        if self.order_window:
            self.order_window.destroy()
        self.order_window = None

def on_order_window_close(self):
    self.order_window = None
        
    def show_recommendations(self, item_id):
        recommendations = self.get_recommendations(item_id)
        self.recommendation_label.config(text=f"Customers also like: {', '.join(recommendations)}")
        
    def show_sentiment(self, text):
        sentiment = self.analyze_sentiment(text)
        emotion = "Positive 😊" if sentiment > 0 else "Negative 😠" if sentiment < 0 else "Neutral 😐"
        messagebox.showinfo("Sentiment Analysis", f"Feedback Emotion: {emotion}\nScore: {sentiment:.2f}")
        
    def enhanced_status_window(self, order_id):
        # Add delivery time prediction
        orders_df = pd.read_excel(ORDERS_FILE)
        order = orders_df[orders_df["OrderID"] == order_id].iloc[0]
        
        if order["Status"] != "Delivered":
            items = list(map(int, order["ItemsOrdered"].split(',')))
            predicted_time = self.predict_delivery_time(items)
            info += f"\nPredicted Delivery Time: {predicted_time:.1f} minutes"
        
        # Rest of status window code...

# Rest of the GUI class and components would follow similar patterns
# with ML integrations added to appropriate sections

if __name__ == "__main__":
    root = tk.Tk()
    app = MLDeliveryBot(root)
    root.mainloop()