# foodbot
AI-Powered Food Delivery Bot – A Python Tkinter app for food ordering with menu browsing, order tracking, and cancellation. Uses ML for delivery time prediction, personalized recommendations, and sentiment analysis to make ordering smarter and interactive.
